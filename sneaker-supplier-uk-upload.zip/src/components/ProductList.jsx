import React from 'react';
import products from '../data/products.json';
import ProductCard from './ProductCard';

const ProductList = () => {
  return (
    <div className="product-list">
      {products.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
};

export default ProductList;
